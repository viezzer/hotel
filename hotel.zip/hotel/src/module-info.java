module hotel {
}